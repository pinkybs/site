var ilasik = {
  test: function(){

  },
  
  // testilasik.html 答题
  testilasik: function(){
    if($('.testilasikBox').length > 0){
      var $testLink =  $('.testilasikBox .testItem .answer a');
	  var $testSubmit = $('.testilasikBox .submit');
	  var answer1,
	      answer2,
		  answer3,
		  answer4,
		  answer5,
		  answer6;
	  
	  $testLink.on('click',function(e){
        var curGroup;
		var curScore;
		
		$(this).siblings('a').removeClass('cur');
        $(this).addClass('cur');
		curGroup = $(this).data('group');
		curScore = $(this).data('score');
		
		switch(curGroup){
			case 1:
			answer1 = curScore;
			break;
			case 2:
			answer2 = curScore;
			break;
			case 3:
			answer3 = curScore;
			break;
			case 4:
			answer4 = curScore;
			break;
			case 5:
			answer5 = curScore;
			break;
			case 6:
			answer6 = curScore;
			break;
		}
        e.preventDefault();
      });
	  
	  $testSubmit.on('click',function(e){
		if(answer1 > 0 && answer2 > 0 && answer3 > 0 && answer4 > 0 && answer5 > 0 && answer6 > 0 ){
			var glbScore = 	answer1 + answer2 + answer3 + answer4 + answer5 + answer6;
			if(glbScore>=10){
			  $('.testilasikBox .testilasikWrap').css({'display':'none'});
			  $('.testilasikBox .result2').css({'display':'block'});	
			}else{
			  $('.testilasikBox .testilasikWrap').css({'display':'none'});
			  $('.testilasikBox .result1').css({'display':'block'});
			} 
		}else{
			alert('亲，请把题答完')	
		}
		e.preventDefault(); 
	  });
	  
    }else{
      return;
    }
  },
  
  // index.html 首页maingif
  mainslide: function(){
    if($('.mainSlide').length > 0 ){
      $('.mainSlide').cycle({
  		  //fx:'scrollHorz',
  		  slides:'> a',
  		  timeout: 4000,
  		  speed: 1000,
  		  easing: 'easeOutQuad'
  		});
  		$('.mainSlide').hover(function(){
  		  $(this).cycle('pause');	
  		},function(){
  		  $(this).cycle('resume');	
  		})
	  }else{
	    return;
	  }
  },
  
  // searchonline.html 下拉搜索框
  dropdown: function(){
    if($('.searchbar').length > 0 ){
      $('.searchbar').find('.dropdown').on('click',function(e){
        var $this = $(this);
        var $tristanSlop = $this.siblings('.tristan_select_op');
        var $showInput = $this.siblings('.showInput');

        $tristanSlop.css({'display':'block'});
        $tristanSlop.find('a').on('click',function(e){
          var curValue = $(this).text();
          $showInput.val(curValue);
          $tristanSlop.css({'display':'none'});
          e.preventDefault();
        });

        e.preventDefault();
      });

      $('.searchbar').find('.form').on('mouseleave',function(){
        $(this).find('.tristan_select_op').css({'display':'none'});
      })

    }else{
    	return;
    }
  }
};
